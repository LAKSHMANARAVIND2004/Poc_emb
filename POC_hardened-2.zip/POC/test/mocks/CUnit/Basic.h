#ifndef MINI_CUNIT_BASIC_H
#define MINI_CUNIT_BASIC_H

/* Real CUnit declares CU_basic_run_tests()/CU_basic_set_mode()/etc. in a
 * separate Basic.h. This shim declares everything in CUnit.h, so this
 * header simply forwards to it to keep #include <CUnit/Basic.h> working
 * unmodified in run_tests.c. */
#include "CUnit.h"

#endif /* MINI_CUNIT_BASIC_H */
